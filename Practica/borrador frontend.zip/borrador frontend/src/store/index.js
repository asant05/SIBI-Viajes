import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    lugar: {
      nombre: '',
      comunidad: undefined,
      provincia: '',
      ruralUrbano:'',
      costaInterior: '',
      monumentos: undefined,
      naturaleza: undefined,
      fiesta: undefined,
      comida: undefined,
      descansoTurismo: undefined,
      queVer: undefined,
    },
   /* numJugadores: undefined,
    estilo: '',
    avg3p: '',
    avgRobos: '',
    avgRebotesDef: '',
    avgAsistencias:'',
    avgTapones:'',
    avgRebotes:'',
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }*/
})